import { getDb } from "../../../db";
import { ensureSeedPrograms } from "../../../db/program-seed";

export async function GET() {
  try {
    const rows = await ensureSeedPrograms(getDb());
    return Response.json({ programs: rows }, { headers: { "Cache-Control": "public, max-age=60, stale-while-revalidate=300" } });
  } catch (error) {
    console.error("Public program list failed", error instanceof Error ? error.message : String(error));
    return Response.json({ error: "The program list is temporarily unavailable." }, { status: 503 });
  }
}
