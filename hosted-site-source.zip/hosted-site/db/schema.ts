import { sql } from "drizzle-orm";
import { index, integer, real, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const programs = sqliteTable("programs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  university: text("university").notNull(),
  country: text("country").notNull(),
  program: text("program").notNull(),
  fee: text("fee").notNull(),
  deadline: text("deadline").notNull(),
  marks: real("marks").notNull(),
  ielts: real("ielts").notNull(),
  documents: text("documents").notNull(),
}, (t) => [uniqueIndex("idx_programs_unique").on(t.university,t.program)]);
export const leads = sqliteTable("leads", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  country: text("country").notNull().default(""),
  marks: text("marks").notNull().default(""),
  ielts: text("ielts").notNull().default(""),
  budget: text("budget").notNull().default(""),
  lastReply: text("last_reply").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});
export const chats = sqliteTable("chats", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  leadId: integer("lead_id").notNull().references(() => leads.id),
  role: text("role").notNull(),
  body: text("body").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index("idx_chats_lead_id").on(t.leadId)]);
export const documents = sqliteTable("documents", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  leadId: integer("lead_id").notNull().references(() => leads.id),
  filename: text("filename").notNull(),
  kind: text("kind").notNull(),
  status: text("status").notNull(),
  reason: text("reason").notNull().default(""),
  objectKey: text("object_key").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
}, (t) => [index("idx_documents_lead_id").on(t.leadId)]);
export const outbox = sqliteTable("outbox", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  leadId: integer("lead_id").notNull().references(() => leads.id),
  body: text("body").notNull(),
  status: text("status").notNull(),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  approvedAt: text("approved_at"),
  sentAt: text("sent_at"),
}, (t) => [index("idx_outbox_status").on(t.status), uniqueIndex("idx_outbox_one_reminder").on(t.leadId,t.body)]);
