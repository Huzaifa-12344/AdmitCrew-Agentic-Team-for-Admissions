import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Nowshera Study Abroad | Staff Desk",
  description: "Staff-controlled student intake, program answers, document reviews, and follow-up approvals.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
