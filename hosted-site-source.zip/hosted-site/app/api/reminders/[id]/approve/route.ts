import { eq } from "drizzle-orm";
import { getDb } from "../../../../../db";
import { outbox } from "../../../../../db/schema";
import { requireAdmin } from "../../../../admin-auth";

export async function POST(_request:Request,{params}:{params:Promise<{id:string}>}) {
  const denied = await requireAdmin(_request);
  if (denied) return denied;
  const {id:raw}=await params; const id=Number(raw);
  if(!Number.isInteger(id)) return Response.json({error:"Invalid reminder."},{status:400});
  try {
    const db=getDb(); const row=(await db.select().from(outbox).where(eq(outbox.id,id)).limit(1))[0];
    if(!row) return Response.json({error:"Reminder not found."},{status:404});
    if(row.status==="sent") return Response.json({status:"sent",note:"This reminder was already approved once."});
    if(row.status!=="pending approval") return Response.json({error:"This reminder is not awaiting approval."},{status:409});
    await db.update(outbox).set({status:"sent",approvedAt:new Date().toISOString(),sentAt:new Date().toISOString()}).where(eq(outbox.id,id));
    return Response.json({status:"sent",note:"Approval recorded once in the dashboard. This demo did not send an external message."});
  } catch(error) {
    console.error("Reminder approval failed",error);
    return Response.json({error:"Approval couldn't be saved. Try again."},{status:503});
  }
}
