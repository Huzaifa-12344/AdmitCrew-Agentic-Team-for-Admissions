import { eq } from "drizzle-orm";
import { env } from "cloudflare:workers";
import { getDb } from "../../../db";
import { documents, leads } from "../../../db/schema";
import { requireAdmin } from "../../admin-auth";

const safeName=(s:string)=>s.replace(/[^A-Za-z0-9._-]/g,"_").slice(0,100)||"student-document.pdf";
export async function POST(request:Request) {
  const denied = await requireAdmin(request);
  if (denied) return denied;
  try {
    const form=await request.formData(); const leadId=Number(form.get("leadId")); const kind=String(form.get("kind")||"Other"); const file=form.get("file");
    if(!Number.isInteger(leadId)||!(file instanceof File)) return Response.json({error:"Choose a student and a PDF document."},{status:400});
    if(file.size<1||file.size>2_000_000||file.type!=="application/pdf") return Response.json({error:"Upload a searchable PDF under 2 MB."},{status:400});
    const db=getDb(); const lead=(await db.select().from(leads).where(eq(leads.id,leadId)).limit(1))[0];
    if(!lead) return Response.json({error:"Choose a valid student."},{status:400});
    const bytes=new Uint8Array(await file.arrayBuffer()); const text=new TextDecoder("latin1").decode(bytes);
    let status="OK",reason="";
    const expiry=text.match(/expir(?:y|es|ed)?\D{0,24}?(\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4}|\d{1,2}[/-]\d{1,2}[/-]\d{4})/i);
    if(expiry) {
      const date=new Date(expiry[1]); if(!Number.isNaN(date.valueOf())&&date<new Date(new Date().toDateString())) {status="Problem";reason="expired";}
    }
    const found=text.match(/name\s*[:=]\s*([A-Za-z][A-Za-z .'-]{2,50})/i)?.[1]?.trim().replace(/[()]+$/g,"");
    if(found&&found.replace(/[^a-z]/gi,"").toLowerCase()!==lead.name.replace(/[^a-z]/gi,"").toLowerCase()){status="Problem";reason=`name does not match ${lead.name}`;}
    if(!env.BUCKET) throw new Error("Document storage is not connected.");
    const key=`student-documents/${leadId}/${crypto.randomUUID()}-${safeName(file.name)}`;
    await env.BUCKET.put(key,bytes,{httpMetadata:{contentType:"application/pdf"}});
    const [saved]=await db.insert(documents).values({leadId,filename:safeName(file.name),kind,status,reason,objectKey:key}).returning({id:documents.id});
    return Response.json({id:saved.id,status,reason,filename:file.name});
  } catch(error) {
    console.error("Document review failed",error);
    return Response.json({error:"The document couldn't be saved and checked. Try again."},{status:503});
  }
}
