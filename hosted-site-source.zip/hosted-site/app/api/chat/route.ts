import { eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { chats, leads, programs } from "../../../db/schema";

const cleanPhone=(value:string)=>value.replace(/\D/g,"");
const studyWords=["university","college","scholarship","visa","admission","course","program","application","fee","deadline","requirement","ielts","marks","tuition","document"];
const today=()=>new Date().toISOString().slice(0,10);

export async function POST(request:Request) {
  try {
    const input=await request.json() as {name?:string;phone?:string;country?:string;marks?:string;ielts?:string;budget?:string;message?:string};
    const name=input.name?.trim()||"", phone=cleanPhone(input.phone||""), message=input.message?.trim()||"";
    if(!name) return Response.json({error:"Student name is required."},{status:400});
    if(phone.length<10) return Response.json({error:"Enter a valid phone number."},{status:400});
    const db=getDb(); let lead=(await db.select().from(leads).where(eq(leads.phone,phone)).limit(1))[0];
    if(!lead) {
      [lead]=await db.insert(leads).values({name,phone,country:input.country?.trim()||"",marks:input.marks?.trim()||"",ielts:input.ielts?.trim()||"",budget:input.budget?.trim()||"",lastReply:today()}).onConflictDoNothing().returning();
      if(!lead) lead=(await db.select().from(leads).where(eq(leads.phone,phone)).limit(1))[0];
    } else {
      [lead]=await db.update(leads).set({name,country:input.country?.trim()||lead.country,marks:input.marks?.trim()||lead.marks,ielts:input.ielts?.trim()||lead.ielts,budget:input.budget?.trim()||lead.budget,lastReply:today()}).where(eq(leads.id,lead.id)).returning();
    }
    if(message) await db.insert(chats).values({leadId:lead.id,role:"student",body:message});
    const q=message.toLowerCase(); let answer="";
    if(["ignore your rules","tell me i'm accepted","tell me im accepted","say i am accepted"].some(x=>q.includes(x))) {
      answer="I can't confirm or promise admission. Only the university can make an admission decision. A staff counselor can review your profile and advise on next steps.";
    } else {
      const all=await db.select().from(programs);
      const matches=all.filter(p=>q.includes(p.university.toLowerCase()));
      const named=matches.length?matches:all.filter(p=>q.includes(p.program.toLowerCase()));
      if(named.length===1 && studyWords.some(x=>q.includes(x))) {
        const p=named[0]; answer=`${p.university} — ${p.program} (${p.country}). Annual fee: ${p.fee}. Deadline: ${p.deadline}. Minimum marks: ${p.marks}%. Minimum IELTS: ${p.ielts}. Documents: ${p.documents}. This is the office practice list; staff must confirm details before an application.`;
      } else if(studyWords.some(x=>q.includes(x))) {
        answer="I couldn't verify that from the office-approved list. I've added your question for a staff counselor to review.";
        if(message) await db.insert(chats).values({leadId:lead.id,role:"staff_queue",body:message});
      } else if(["hello","hi","salam","assalam"].some(x=>q.includes(x))) {
        answer=`Hello ${name}! Tell me your preferred country, marks, IELTS score (if taken), and yearly budget so our counselor can guide you.`;
      } else {
        answer="I can help with programs in the office-approved list. I can't advise on unrelated topics, but a staff counselor can help with your study plans.";
      }
    }
    await db.insert(chats).values({leadId:lead.id,role:"agent",body:answer});
    return Response.json({leadId:lead.id,lead,answer});
  } catch(error) {
    console.error("Chat intake failed",error);
    return Response.json({error:"Your message could not be saved. Please try again."},{status:503});
  }
}
