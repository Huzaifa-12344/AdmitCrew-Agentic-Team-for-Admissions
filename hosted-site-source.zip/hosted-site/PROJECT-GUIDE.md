# Nowshera Study Abroad Agent Desk

This is the hosted, responsive website source for the Nowshera Study Abroad Consultants demo. Students can browse the office's 15 example programs and submit an inquiry. Staff sign in to view the private overview, chats, uploaded document checks, and follow-up drafts.

## Local development

Requirements: Node.js 22.13 or newer and Git.

```bash
npm run install:ci
cp .dev.vars.example .dev.vars
# Edit .dev.vars with private local values before starting the server.
npm run dev
```

Open the local URL printed by the dev server. The Site uses Cloudflare D1 (`DB`) for records and R2 (`BUCKET`) for document files. For a local preview, follow the D1 migration steps in `README.md` before testing storage or staff pages.

## Staff sign-in and privacy

The public website exposes only the example program catalog and the student inquiry form. Staff endpoints require the HttpOnly admin session. Set `ADMIN_PASSWORD` and `ADMIN_SESSION_SECRET` as encrypted runtime secrets in Sites; never commit either value or put it in browser code. Student records and documents are not returned by public routes.

The password is configured as a runtime secret, not embedded in source. Keep it private and change it in Sites settings if it is shared beyond the office. The staff overview is behind the password gate.

## Agent limits

- Program answers are generated from the seeded office list only; example fees and dates are not verified admissions advice.
- The document checker handles the supplied fictional, text-searchable PDFs. It is not OCR and does not determine eligibility.
- The scheduled `/api/reminders/run` endpoint creates idempotent drafts only. A staff member must approve each draft in the dashboard.
- `n8n/reminder-drafts-every-minute.json` is the matching n8n workflow export. Import it and activate the schedule in n8n; it calls the draft-only endpoint once per minute.
- **Approving a draft records it in the demo outbox; it does not deliver email, WhatsApp, or SMS.** An email provider and its private credentials are not configured in this source.
- Website inquiries are not yet connected to WhatsApp or Facebook inboxes.

## Repeatable tests

From the repository root, run `python3 tests/run_tests.py` for the seven acceptance checks of the standard-library demo. The Site build also has `npm run lint`; these checks do not send any external student messages.
