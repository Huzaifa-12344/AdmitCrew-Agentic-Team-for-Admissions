import { asc } from "drizzle-orm";
import type { getDb } from "./index";
import { programs } from "./schema";

const seedPrograms = [
  ["University of Manchester","UK","BSc Computer Science","£32,000","15 Jan 2027",75,6.5,"Passport, transcript, IELTS"],
  ["University of Leeds","UK","BSc Business Management","£27,000","31 Jan 2027",70,6.5,"Passport, transcript, IELTS, personal statement"],
  ["University of Toronto","Canada","BSc Computer Science","CAD 60,000","15 Jan 2027",80,6.5,"Passport, transcript, IELTS"],
  ["TU Munich","Germany","BSc Informatics","No tuition (about €150 a term)","15 Jul 2027",70,6.5,"Passport, transcript, IELTS"],
  ["Monash University","Australia","Bachelor of IT","AUD 48,000","30 Nov 2026",70,6,"Passport, transcript, IELTS"],
  ["University of Bristol","UK","BSc Data Science","£31,300","26 Jan 2027",75,6.5,"Passport, transcript, IELTS, personal statement"],
  ["University of Glasgow","UK","BSc Software Engineering","£29,700","31 Jan 2027",70,6.5,"Passport, transcript, IELTS"],
  ["University of Alberta","Canada","BSc Computing Science","CAD 36,000","01 Mar 2027",75,6.5,"Passport, transcript, IELTS"],
  ["McGill University","Canada","BSc Economics","CAD 55,000","15 Jan 2027",85,6.5,"Passport, transcript, IELTS, references"],
  ["University of Waterloo","Canada","BSc Mathematics","CAD 63,000","01 Feb 2027",85,6.5,"Passport, transcript, IELTS"],
  ["University of Sydney","Australia","Bachelor of Commerce","AUD 52,500","30 Nov 2026",75,6.5,"Passport, transcript, IELTS"],
  ["University of Queensland","Australia","Bachelor of Engineering","AUD 50,560","30 Nov 2026",75,6.5,"Passport, transcript, IELTS"],
  ["RWTH Aachen University","Germany","BSc Mechanical Engineering","No tuition (semester contribution applies)","15 Jul 2027",75,6.5,"Passport, transcript, IELTS"],
  ["University of Hamburg","Germany","BSc Molecular Life Sciences","No tuition (semester contribution applies)","15 Jul 2027",70,6.5,"Passport, transcript, IELTS"],
  ["University of Adelaide","Australia","Bachelor of Computer Science","AUD 49,500","30 Nov 2026",70,6,"Passport, transcript, IELTS"],
] as const;

export async function ensureSeedPrograms(db: ReturnType<typeof getDb>) {
  const existing = await db.select().from(programs).orderBy(asc(programs.id));
  if (existing.length < seedPrograms.length) {
    for (let start=0;start<seedPrograms.length;start+=10) {
      const chunk=seedPrograms.slice(start,start+10).map(([university,country,program,fee,deadline,marks,ielts,documents])=>({university,country,program,fee,deadline,marks,ielts,documents}));
      await db.insert(programs).values(chunk).onConflictDoNothing();
    }
  }
  return db.select().from(programs).orderBy(asc(programs.country),asc(programs.university));
}
