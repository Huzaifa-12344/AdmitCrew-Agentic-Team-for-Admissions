import { clearAdminCookie } from "../../../admin-auth";

export async function POST() {
  return Response.json({ authenticated: false }, { headers: { "Set-Cookie": clearAdminCookie(), "Cache-Control": "no-store" } });
}
