import { authIsConfigured, issueAdminCookie, passwordMatches } from "../../../admin-auth";

export async function POST(request: Request) {
  if (!authIsConfigured()) return Response.json({ error: "Admin sign-in is not configured. Contact the site owner." }, { status: 503 });
  try {
    const body = await request.json() as { password?: string };
    if (typeof body.password !== "string" || !(await passwordMatches(body.password))) {
      return Response.json({ error: "Password is incorrect. Try again." }, { status: 401 });
    }
    return Response.json({ authenticated: true }, { headers: { "Set-Cookie": await issueAdminCookie(), "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Could not sign in. Try again." }, { status: 400 });
  }
}
