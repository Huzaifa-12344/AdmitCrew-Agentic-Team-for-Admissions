import { asc, desc, eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { chats, documents, leads, outbox } from "../../../db/schema";
import { requireAdmin } from "../../admin-auth";
import { ensureSeedPrograms } from "../../../db/program-seed";
const today = () => new Date().toISOString().slice(0,10);

export async function GET(request: Request) {
  const denied = await requireAdmin(request);
  if (denied) return denied;
  try {
    const db = getDb();
    const programRows=await ensureSeedPrograms(db);
    const date = today();
    const quietDate = new Date(Date.now() - 4*86400000).toISOString().slice(0,10);
    await db.insert(leads).values([
      { name:"Ali Khan", phone:"03012345678", country:"UK", marks:"78%", ielts:"6.5", lastReply:date },
      { name:"Ayesha Noor", phone:"03339876543", country:"Canada", marks:"85%", ielts:"7.0", lastReply:date },
      { name:"Hamza Iqbal", phone:"03462223344", country:"UK", marks:"69%", ielts:"Not taken yet", lastReply:quietDate },
    ]).onConflictDoNothing();
    const [leadRows, chatRows, docRows, outboxRows] = await Promise.all([
      db.select().from(leads).orderBy(asc(leads.id)),
      db.select({id:chats.id,leadId:chats.leadId,role:chats.role,body:chats.body,createdAt:chats.createdAt,name:leads.name,phone:leads.phone}).from(chats).innerJoin(leads,eq(chats.leadId,leads.id)).orderBy(desc(chats.id)).limit(100),
      db.select({id:documents.id,leadId:documents.leadId,filename:documents.filename,kind:documents.kind,status:documents.status,reason:documents.reason,createdAt:documents.createdAt,name:leads.name,phone:leads.phone}).from(documents).innerJoin(leads,eq(documents.leadId,leads.id)).orderBy(desc(documents.id)),
      db.select({id:outbox.id,leadId:outbox.leadId,body:outbox.body,status:outbox.status,createdAt:outbox.createdAt,sentAt:outbox.sentAt,name:leads.name,phone:leads.phone}).from(outbox).innerJoin(leads,eq(outbox.leadId,leads.id)).orderBy(desc(outbox.id)),
    ]);
    return Response.json({programs:programRows,leads:leadRows,chats:chatRows.reverse(),documents:docRows,outbox:outboxRows,counts:{programs:programRows.length,leads:leadRows.length,chats:chatRows.length,documents:docRows.length,pending:outboxRows.filter(x=>x.status==="pending approval").length}},{headers:{"Cache-Control":"private, no-store"}});
  } catch (error) {
    console.error("State load failed",error instanceof Error?`${error.name}: ${error.message}`:String(error));
    return Response.json({error:"Student workspace is temporarily unavailable. Try refreshing in a moment."},{status:503});
  }
}
