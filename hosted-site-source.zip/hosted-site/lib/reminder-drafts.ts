import { and, eq } from "drizzle-orm";
import { getDb } from "../db";
import { leads, outbox } from "../db/schema";

export async function createReminderDrafts() {
  const db = getDb();
  const people = await db.select().from(leads);
  let created = 0;

  for (const person of people) {
    const lastReply = new Date(`${person.lastReply}T00:00:00Z`).getTime();
    if (!Number.isFinite(lastReply) || (Date.now() - lastReply) / 86_400_000 < 3) continue;

    const body = `Hi ${person.name}, just checking in on your study abroad plans. If you would like, reply with your preferred country or any questions and a counselor will help.`;
    const [existing] = await db.select({ id: outbox.id }).from(outbox)
      .where(and(eq(outbox.leadId, person.id), eq(outbox.body, body))).limit(1);
    if (existing) continue;

    await db.insert(outbox).values({ leadId: person.id, body, status: "pending approval" }).onConflictDoNothing();
    created++;
  }

  return created;
}
