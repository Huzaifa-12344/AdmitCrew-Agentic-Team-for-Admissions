import { env } from "cloudflare:workers";

const COOKIE = "nowshera_admin_session";
const SESSION_SECONDS = 8 * 60 * 60;
type AuthEnv = { ADMIN_PASSWORD?: string; ADMIN_SESSION_SECRET?: string };
const authEnv = env as unknown as AuthEnv;

function configured() {
  return Boolean(authEnv.ADMIN_PASSWORD && authEnv.ADMIN_SESSION_SECRET);
}

function toBase64Url(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function fromBase64Url(value: string) {
  const base64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const binary = atob(base64 + "=".repeat((4 - (base64.length % 4)) % 4));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

async function sign(value: string) {
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(authEnv.ADMIN_SESSION_SECRET!),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return toBase64Url(new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value))));
}

export async function passwordMatches(candidate: string) {
  if (!configured()) return false;
  const encoder = new TextEncoder();
  const [provided, expected] = await Promise.all([
    crypto.subtle.digest("SHA-256", encoder.encode(candidate)),
    crypto.subtle.digest("SHA-256", encoder.encode(authEnv.ADMIN_PASSWORD!)),
  ]);
  const a = new Uint8Array(provided);
  const b = new Uint8Array(expected);
  let difference = 0;
  for (let i = 0; i < a.length; i++) difference |= a[i] ^ b[i];
  return difference === 0;
}

export function authIsConfigured() {
  return configured();
}

export async function issueAdminCookie() {
  const expires = Math.floor(Date.now() / 1000) + SESSION_SECONDS;
  const token = `${expires}.${await sign(String(expires))}`;
  return `${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${SESSION_SECONDS}`;
}

export function clearAdminCookie() {
  return `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

export async function isAdminRequest(request: Request) {
  if (!configured()) return false;
  const raw = request.headers.get("cookie")?.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${COOKIE}=`))?.slice(COOKIE.length + 1);
  if (!raw) return false;
  const [expiry, signature, extra] = raw.split(".");
  if (!expiry || !signature || extra || !/^\d+$/.test(expiry) || Number(expiry) <= Math.floor(Date.now() / 1000)) return false;
  try {
    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(authEnv.ADMIN_SESSION_SECRET!),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["verify"],
    );
    return await crypto.subtle.verify("HMAC", key, fromBase64Url(signature), new TextEncoder().encode(expiry));
  } catch {
    return false;
  }
}

export async function requireAdmin(request: Request) {
  if (!configured()) {
    return Response.json({ error: "Admin sign-in is not configured. Contact the site owner." }, { status: 503 });
  }
  if (!(await isAdminRequest(request))) {
    return Response.json({ error: "Admin sign-in is required." }, { status: 401 });
  }
  return null;
}
