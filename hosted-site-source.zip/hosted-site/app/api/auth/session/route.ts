import { authIsConfigured, isAdminRequest } from "../../../admin-auth";

export async function GET(request: Request) {
  return Response.json({ configured: authIsConfigured(), authenticated: await isAdminRequest(request) });
}
