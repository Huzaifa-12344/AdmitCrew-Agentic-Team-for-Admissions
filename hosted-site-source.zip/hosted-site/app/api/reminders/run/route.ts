import { createReminderDrafts } from "../../../../lib/reminder-drafts";

// n8n calls this endpoint on its schedule. It can create pending drafts only;
// approval and all student-record reads remain behind the staff login.
export async function POST() {
  try {
    const created = await createReminderDrafts();
    return Response.json(
      { created, status: "pending staff approval", note: "No student message was sent." },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch (error) {
    console.error("Scheduled reminder draft run failed", error);
    return Response.json({ error: "Reminder drafts are temporarily unavailable." }, { status: 503 });
  }
}
