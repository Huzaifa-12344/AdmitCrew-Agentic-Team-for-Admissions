import { requireAdmin } from "../../admin-auth";
import { createReminderDrafts } from "../../../lib/reminder-drafts";

export async function POST(request: Request) {
  const denied = await requireAdmin(request);
  if (denied) return denied;
  try {
    const created=await createReminderDrafts();
    return Response.json({created,note:"Drafts need staff approval. No message is sent until staff reviews it."},{headers:{"Cache-Control":"no-store"}});
  } catch(error) {
    console.error("Reminder run failed",error);
    return Response.json({error:"Reminder drafts are temporarily unavailable."},{status:503});
  }
}
